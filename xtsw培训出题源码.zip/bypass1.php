<?php
include("flag111.php");
header("Content-Type:text/html;charset=utf-8");
show_source(__FILE__);
$str = $_GET['str'];

if($str==md5(md5($str))){
	echo $flag;//yes is here
} else{
	echo "nonono";
}

