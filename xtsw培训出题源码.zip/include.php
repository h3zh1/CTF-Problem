<?php

echo "?file=wowo<br/>";
$file = $_GET['file'];
//go to the ssrf.php and the flag is in /flag
if( stristr($file,'flag') ){
	die("no flag<br/>");
}
if( stristr($file,"php://filter") ){
	echo "ok<br/>";
	include($file);
} else{
	die("no<br/>");
}