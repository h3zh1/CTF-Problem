<?php
//error_reporting(11);
header("Content-Type: text/html; charset=utf8");
error_reporting(0);
echo "一道炒鸡无比简单的sql题,用尽你的办法拿到flag叭<br/><br/>
	 	Hint:?id=1<br/><br/>
	 ";

$server_address = "localhost";
$user_name = "root";
$password = "";
$database = "f14g";
$conn = new mysqli( $server_address, $user_name, $password, $database,3306) ;

$id = $_GET['id'];
if(!isset($_GET['id'])){
	$id = 1;
}
$sql= "select * from wowo where id = $id ";
//echo $sql;
$result = $conn->query($sql);
//var_dump($result);
if(!$result){ //出错报错
	printf("error message: %s\n", $conn->error);
}
/* 
$row = $result->fetch_array();//生成数组的形势
echo " id ==> $row[0] <br/>";
echo " name ==> $row[1] <br/>";
echo " commit ==> $row[2] <br/>";
*/

echo '<table border="1">
		<tr>
    		<th>ID</th>
    		<th>Name</th>
    		<th>Commit</th>
		   </tr> ';	   
$row = $result->fetch_array() ;
	echo "<tr>
			<td>$row[0]</td>
    		<td>$row[1] </td>
  			<td>$row[2] </td>
  		</tr>";

echo "</table>";

mysqli_close($conn);

?>