<?php
error_reporting(0);
header("Content-Type:text/html;charset=utf-8");
show_source(__FILE__);
//flag在根目录,自己找一下吧
echo "李老板让我出点难的题,我偷偷改成了签到题,加油奥哇各位~。";

Class Ani{
	private $name = "PiPi";
	protected $choice = 233;
	public $chui_k_t = "wo";
	
	public function lianzi(){//miaomiaomiao
		$this->vAndN();
	}
	public function vAndN(){//
		
		if($this->choice===1){
			echo system($this->chui_k_t);	
		} else{
			echo "拜拜了您";
		}
		
	}

	public function miao(){//miaomiaomiao
		echo file_get_contents("there_is_nothing.txt");
	}

	public function __destruct(){
		if($this->name!='jie_ni_jie_ni')
			$this->choice=233;

		$this->lianzi();
	}

	
}
if( isset($_GET['code']) ){
	$ani = unserialize($_GET['code']);
} else {
	die("?code=");
}


?>

