
<?php
//error_reporting(11);
header("Content-Type: text/html; charset=utf8");
error_reporting(0);
echo "炒鸡新的一道,炒鸡无比简单的sql题,用尽你的办法拿到flag叭,hint:?id=233<br/><br/>
	 ";

$server_address = "localhost";
$user_name = "root";
$password = "";
$database = "web_sql_2";
$conn = new mysqli( $server_address, $user_name, $password, $database,3306) ;


if( !isset($_GET['id']) ){
	$id = 1;
} else{
	$id = $_GET['id'];
}
if(strstr($id,' ')||strstr($id,'--')||strstr($id,'/**/')||stristr($id,'union')||stristr($id,';')||
   stristr($id,'web_sql_2') ) {
	die("hacker");
}

$sql= "select * from sql2 where id = $id ";


$result = $conn->query($sql);

echo '<table border="1">
		<tr>
    		<th>ID</th>
    		<th>First</th>
		   </tr> ';	   
$row = $result->fetch_array() ;
	echo "<tr>
			<td>$row[0]</td>
    		<td>$row[1] </td>
  		</tr>";

echo "</table>";

mysqli_close($conn);

?>