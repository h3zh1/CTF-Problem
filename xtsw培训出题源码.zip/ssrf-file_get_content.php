<?php
error_reporting(0);
header("Content-Type:text/html;charset=utf-8");
//highlight_file(__FILE__);



if( md5($_GET['var1'])==md5($_GET['var2']) && $_GET['var1']!=$_GET['var2'] ){
	
	$url=$_GET['url'];
	
	$content=base64_encode(file_get_contents($url));
	
	echo($content);
	
} else{
	die();
}


?>