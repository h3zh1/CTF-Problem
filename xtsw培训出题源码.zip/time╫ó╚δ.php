<?php
//error_reporting(11);
error_reporting(0);
header("Content-Type: text/html; charset=utf8");

echo "Time,Time<br/><br/>
	 	Hint:post a num<br/><br/>
	 ";
//flag{Time_1s_v3ry_precious_t0_us}
$server_address = "localhost";
$user_name = "root";
$password = "";
$database = "timedb";
$conn = new mysqli( $server_address, $user_name, $password, $database,3306) ;

$id = $_POST['num'];

$sql= "select * from people where id = $id ";
//echo $sql;
$result = $conn->query($sql);



mysqli_close($conn);

?>