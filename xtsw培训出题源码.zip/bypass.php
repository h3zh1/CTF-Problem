<?php
error_reporting(0);
header("Content-Type:text/html;charset=utf-8");
show_source(__FILE__);
include "flag_for_bypass.php";


//level one
if(isset($_GET['num'])){
	$num = $_GET['num'];

	if( strlen($num)<6&& $num>99999 ) {
		echo "干的不错,少吹空调 <br/>";
	} else{
		die("多喝岩浆<br/><br/>");
	}

}else{
	die();
}

if(isset($_GET['var1'])&&isset($_GET['var2'])){
	
	if( sha1($_GET['var1'])===sha1($_GET['var2']) && $_GET['var1']!=$_GET['var2']){
		echo "Nice 起飞，我能去你家过年吗  <br/>";
	} else{
		die( "就浙, 就浙??? <br/>" );
	}

}else{
	die();
}

$data = $_GET['data'];
if(file_get_contents($data)==='xingtai'){
	echo $flag;
} else{
	die("我好饿，能给我点个外卖吗; 我能去你家过年不?");
}
