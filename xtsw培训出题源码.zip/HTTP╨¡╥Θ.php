<?php
header("Content-Type: text/html;charset=utf-8");
echo "Flag被分成了3部分,我再此留下了4个任务,你每完成一部分我就会给你一部分flag线索。<br/>";

echo "!!!我把一些小提示放在了robots.txt奥<br/>";
//flag{good_job_th1s_is_an_easy_pr0blem_about_htt9}

if($_GET['account']==='admin'){
	echo "喔~第一部分给你啦:'flag{good_job_'<br/><br/>";
} else {
	die("1.请传一个get参数,名为account,值为admin<br/><br/>");
}

$UA = $_SERVER['HTTP_USER_AGENT'];
//echo $UA;
if( strstr($UA,"XXTT") ){
	echo "芜湖!第二部分:'th1s_is_an_easy_pr0blem'<br/><br/>";
} else {
	die("2.只有在使用'XXTT'浏览器才可以得到第二部分flag。<br/><br/>");
}

if($_SERVER['HTTP_REFERER']==='www.cnblogs.com/h3zh1'){
	echo "你竟然通过了,最后一部分flag只能本地访问才可以给你哦!‘你的ip要是来自本机就好了’。<br/><br/>";
} else {
	die( "3.You should come from www.cnblogs.com/h3zh1。<br/><br/>");
}

$xff = $_SERVER['HTTP_X_FORWARDED_FOR'];
//echo $xff;

if( strstr($xff,"127.0.0.1") || strstr($xff,"localhost") ){
	echo "歪瑞古德,最后一半弗莱格给宁'_about_htt9}'<br/><br/>";
	echo "完整的flag:flag{good_job_th1s_is_an_easy_pr0blem_about_htt9}";
} 
