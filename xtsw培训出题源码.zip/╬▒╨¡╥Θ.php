<?php
error_reporting(0);
header("Content-Type:text/html;charset=utf-8");
highlight_file(__FILE__);

$file = $_POST['file'];
echo "Please Post a file & the flag is in /flag.txt <br/>";

if(strpos('php',$file)){
	die("<br/><br/><br/>No No No not php");
}
include($file);
